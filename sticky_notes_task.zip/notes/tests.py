"""Unit tests for the notes application."""
from django.test import TestCase
from django.urls import reverse

from .models import Note


class NoteModelTest(TestCase):
    """Tests for the Note model."""

    def setUp(self):
        """Create a test note."""
        Note.objects.create(title="Test Note", content="This is a test note.")

    def test_note_title(self):
        """Ensure the note title is saved correctly."""
        note = Note.objects.get(id=1)
        self.assertEqual(note.title, "Test Note")

    def test_note_content(self):
        """Ensure the note content is saved correctly."""
        note = Note.objects.get(id=1)
        self.assertEqual(note.content, "This is a test note.")


class NoteViewTest(TestCase):
    """Tests for note views."""

    def setUp(self):
        """Create a test note for view tests."""
        self.note = Note.objects.create(title="Test Note", content="This is a test note.")

    def test_note_list_view(self):
        """Ensure the note list page loads and contains the note title."""
        response = self.client.get(reverse("note_list"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Test Note")

    def test_note_detail_view(self):
        """Ensure the note detail page loads with the correct content."""
        response = self.client.get(reverse("note_detail", args=[self.note.id]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Test Note")
        self.assertContains(response, "This is a test note.")

    def test_note_create_view(self):
        """Ensure a note can be created through the create view."""
        response = self.client.post(
            reverse("note_create"),
            {"title": "Created Note", "content": "Created by test."},
        )
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Note.objects.filter(title="Created Note").exists())

    def test_note_delete_view(self):
        """Ensure a note can be deleted through the delete view."""
        response = self.client.post(reverse("note_delete", args=[self.note.id]))
        self.assertEqual(response.status_code, 302)
        self.assertFalse(Note.objects.filter(id=self.note.id).exists())
