"""Database models for the notes application."""
from django.db import models


class Note(models.Model):
    """Represents a single sticky note."""

    title = models.CharField(max_length=200)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        """Return the note title as its string representation."""
        return self.title
